<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "discover_saudi",
    3307
);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

?>