<?php
include("auth.php");
include("../includes/db.php");

$query = "SELECT * FROM regions";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>

<header>
    <nav class="navbar">
        <h2 class="logo">لوحة التحكم</h2>

        <div>
            <a href="../index.php">الرئيسية</a>
            <a href="../regions.php">معرض المناطق</a>
            <a href="add.php">إضافة منطقة</a>
            <a href="logout.php">تسجيل خروج</a>
        </div>
    </nav>
</header>

<main class="admin-container">
    <?php if (isset($_GET["msg"])) { ?>

    <?php if ($_GET["msg"] == "updated") { ?>
        <p class="success-message">تم تحديث المنطقة بنجاح</p>
    <?php } ?>

    <?php if ($_GET["msg"] == "deleted") { ?>
        <p class="success-message">تم حذف المنطقة بنجاح</p>
    <?php } ?>

    <?php if ($_GET["msg"] == "added") { ?>
        <p class="success-message">تمت إضافة المنطقة بنجاح</p>
    <?php } ?>

<?php } ?>

    <h1>إدارة المناطق</h1>

    <table class="admin-table">

        <tr>
            <th>ID</th>
            <th>الاسم</th>
            <th>التصنيف</th>
            <th>الصورة</th>
            <th>التحكم</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <tr>
            <td><?php echo $row["id"]; ?></td>

            <td><?php echo $row["name"]; ?></td>

            <td><?php echo $row["category"]; ?></td>

            <td>
                <img class="table-image"
                src="../images/<?php echo $row["main_image"]; ?>">
            </td>

            <td>
                <a class="edit-btn"
                href="edit.php?id=<?php echo $row["id"]; ?>">
                تعديل
                </a>

                <a class="delete-btn"
                onclick="return confirm('هل أنت متأكد من الحذف؟')"
                href="delete.php?id=<?php echo $row["id"]; ?>">
                حذف
                </a>
            </td>
        </tr>

        <?php } ?>

    </table>

</main>

</body>
</html>