<?php
include("auth.php");
include("../includes/db.php");

if (!isset($_GET["id"])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET["id"];

$query = "DELETE FROM regions WHERE id = $id";
mysqli_query($conn, $query);

header("Location: dashboard.php?msg=deleted");
exit();
?>