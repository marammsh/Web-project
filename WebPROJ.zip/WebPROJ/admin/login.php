<?php
session_start();
include("../includes/db.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (empty($username) || empty($password)) {
        $error = "يرجى إدخال اسم المستخدم وكلمة المرور";
    } else {
        $query = "SELECT * FROM admins WHERE username='$username' AND password='$password'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 1) {
            $admin = mysqli_fetch_assoc($result);
            $_SESSION["admin_id"] = $admin["id"];
            $_SESSION["admin_username"] = $admin["username"];

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "اسم المستخدم أو كلمة المرور غير صحيحة";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>تسجيل دخول المشرف</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>

<header>
    <nav class="navbar">
        <h2 class="logo">لوحة المشرف</h2>
        <div>
            <a href="../index.php">الرئيسية</a>
            <a href="../regions.php">معرض المناطق</a>
        </div>
    </nav>
</header>

<main class="admin-container">

    <form class="admin-form" method="POST" action="">
        <h2>تسجيل دخول المشرف</h2>

        <?php if ($error != "") { ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php } ?>

        <label>اسم المستخدم</label>
        <input type="text" name="username">

        <label>كلمة المرور</label>
        <input type="password" name="password">

        <input type="submit" value="دخول">
    </form>

</main>

</body>
</html>