<?php
include("auth.php");
include("../includes/db.php");

if (!isset($_GET["id"])) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET["id"];

$selectQuery = "SELECT * FROM regions WHERE id = $id";
$result = mysqli_query($conn, $selectQuery);
$region = mysqli_fetch_assoc($result);

if (!$region) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $category = $_POST["category"];
    $short_description = $_POST["short_description"];
    $description = $_POST["description"];
    $history = $_POST["history"];
    $landmarks = $_POST["landmarks"];
    $main_image = $_POST["main_image"];
    $image1 = $_POST["image1"];
    $image2 = $_POST["image2"];
    $image3 = $_POST["image3"];

    $updateQuery = "UPDATE regions SET
        name = '$name',
        category = '$category',
        short_description = '$short_description',
        description = '$description',
        history = '$history',
        landmarks = '$landmarks',
        main_image = '$main_image',
        image1 = '$image1',
        image2 = '$image2',
        image3 = '$image3'
        WHERE id = $id";

    mysqli_query($conn, $updateQuery);

    header("Location: dashboard.php?msg=updated");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
<meta charset="UTF-8">
<title>تعديل المنطقة</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<header>
<nav class="navbar">
<h2 class="logo">تعديل المنطقة</h2>

<div>
<a href="dashboard.php">لوحة التحكم</a>
<a href="add.php">إضافة منطقة</a>
<a href="logout.php">تسجيل خروج</a>
</div>
</nav>
</header>

<main class="admin-container">

<form class="admin-form" method="POST">

<h2>تعديل بيانات المنطقة</h2>

<label>اسم المنطقة</label>
<input type="text" name="name" value="<?php echo $region['name']; ?>" required>

<label>التصنيف</label>
<select name="category" required>
<option value="تاريخية" <?php if($region['category'] == "تاريخية") echo "selected"; ?>>تاريخية</option>
<option value="دينية" <?php if($region['category'] == "دينية") echo "selected"; ?>>دينية</option>
<option value="تراثية" <?php if($region['category'] == "تراثية") echo "selected"; ?>>تراثية</option>
<option value="ترفيه" <?php if($region['category'] == "ترفيه") echo "selected"; ?>>ترفيه</option>
</select>

<label>وصف مختصر</label>
<textarea name="short_description" required><?php echo $region['short_description']; ?></textarea>

<label>الوصف الكامل</label>
<textarea name="description" required><?php echo $region['description']; ?></textarea>

<label>المعلومات التاريخية</label>
<textarea name="history" required><?php echo $region['history']; ?></textarea>

<label>المعالم</label>
<textarea name="landmarks" required><?php echo $region['landmarks']; ?></textarea>

<label>الصورة الرئيسية</label>
<input type="text" name="main_image" value="<?php echo $region['main_image']; ?>" required>

<label>الصورة الثانية</label>
<input type="text" name="image1" value="<?php echo $region['image1']; ?>">

<label>الصورة الثالثة</label>
<input type="text" name="image2" value="<?php echo $region['image2']; ?>">

<label>الصورة الرابعة</label>
<input type="text" name="image3" value="<?php echo $region['image3']; ?>">

<input type="submit" value="حفظ التعديل">

</form>

</main>

</body>
</html>